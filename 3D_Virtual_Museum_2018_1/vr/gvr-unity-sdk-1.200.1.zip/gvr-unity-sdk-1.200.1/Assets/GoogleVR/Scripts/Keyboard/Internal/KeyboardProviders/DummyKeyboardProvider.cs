//-----------------------------------------------------------------------
// <copyright file="DummyKeyboardProvider.cs" company="Google Inc.">
// Copyright 2017 Google Inc. All rights reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// </copyright>
//-----------------------------------------------------------------------

using UnityEngine;

namespace Gvr.Internal
{
    class DummyKeyboardProvider : IKeyboardProvider
    {
        private KeyboardState dummyState = new KeyboardState();

        internal DummyKeyboardProvider()
        {
        }

        public void ReadState(KeyboardState outState)
        {
            outState.CopyFrom(dummyState);
        }

        public void OnPause()
        {
        }

        public void OnResume()
        {
        }

        public void UpdateData()
        {
        }

        public void Render(int eye, Matrix4x4 modelview, Matrix4x4 projection, Rect viewport)
        {
        }

        public void Hide()
        {
        }

        public void Show(Matrix4x4 controllerMatrix, bool useRecommended, float distance,
                         Matrix4x4 model)
        {
        }

        public bool Create(GvrKeyboard.KeyboardCallback keyboardEvent)
        {
            return true;
        }

        public void SetInputMode(GvrKeyboardInputMode mode)
        {
        }

        public string EditorText { get; set; }
    }
}
